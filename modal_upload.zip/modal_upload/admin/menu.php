<div id="left-menu">
              <div class="sub-left-menu scroll">
                <ul class="nav nav-list">
                    <li><div class="left-bg"></div></li>
                    <li class="time">
                      <h1 class="animated fadeInLeft">21:00</h1>
                      <p class="animated fadeInRight">Sat,October 1st 2029</p>
                    </li>
                    <li><a href="index.php"><span class="fa-dashboard fa"></span> Dashboard</a></li>
                    
                    
                   <!--  <li class="ripple">
                      <a class="tree-toggle nav-header">
                        <span class="fa-lock fa"></span> Admin
                        <span class="fa-angle-right fa right-arrow text-right"></span>
                      </a>
                      <ul class="nav nav-list tree">
                        <li><a href="index.php">Data Admin</a></li>
                      </ul>
                    </li> -->
                    
                    
                  </ul>
                </div>
            </div>