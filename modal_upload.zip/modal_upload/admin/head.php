<head>
	
	 <meta charset="utf-8">
  <meta name="description" content="Modal upload image di php| www.hakkoblogs.com">
  <meta name="author" content="Hakko Bio Richard">
  <meta name="keyword" content="Aplikasi, Scan, Barcode, Makan, www.hakkoblogs.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Modal upload image di php| www.hakkoblogs.com</title>
 
    <!-- start: Css -->
    <link rel="stylesheet" type="text/css" href="asset/css/bootstrap.min.css">

      <!-- plugins -->
      <link rel="stylesheet" type="text/css" href="asset/css/plugins/font-awesome.min.css"/>
      <link rel="stylesheet" type="text/css" href="asset/css/plugins/simple-line-icons.css"/>
      <link rel="stylesheet" type="text/css" href="asset/css/plugins/animate.min.css"/>
      <link rel="stylesheet" type="text/css" href="asset/css/plugins/fullcalendar.min.css"/>
      <link rel="stylesheet" href="asset/datepicker/datepicker3.css">
      <link rel="stylesheet" type="text/css" href="asset/css/plugins/datatables.bootstrap.min.css"/>
	<link href="asset/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="asset/select2/select2.min.css">
	<!-- end: Css -->
    
    <script src="../dist/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="../dist/sweetalert.css">

	<link rel="shortcut icon" href="asset/img/logomi.png">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>